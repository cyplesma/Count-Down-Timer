﻿namespace CountDownTimer
{
    partial class frmMainCountDownTimer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dtpTargetDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCountDownDisplay = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.tmrCountHerDown = new System.Windows.Forms.Timer(this.components);
            this.btnCountDown = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHoursToCountDown = new System.Windows.Forms.TextBox();
            this.lblTargetDate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dtpTargetDate
            // 
            this.dtpTargetDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTargetDate.Location = new System.Drawing.Point(252, 190);
            this.dtpTargetDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpTargetDate.Name = "dtpTargetDate";
            this.dtpTargetDate.Size = new System.Drawing.Size(124, 20);
            this.dtpTargetDate.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(101, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 9);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select Target Date";
            // 
            // lblCountDownDisplay
            // 
            this.lblCountDownDisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblCountDownDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCountDownDisplay.Font = new System.Drawing.Font("Alien Encounters Solid", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountDownDisplay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblCountDownDisplay.Location = new System.Drawing.Point(22, 44);
            this.lblCountDownDisplay.Name = "lblCountDownDisplay";
            this.lblCountDownDisplay.Size = new System.Drawing.Size(695, 92);
            this.lblCountDownDisplay.TabIndex = 2;
            this.lblCountDownDisplay.Text = "XD  HH:MM:SS";
            this.lblCountDownDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(464, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 9);
            this.label3.TabIndex = 4;
            this.label3.Text = "Select Target Time";
            // 
            // dtpTime
            // 
            this.dtpTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpTime.Location = new System.Drawing.Point(584, 190);
            this.dtpTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.Size = new System.Drawing.Size(124, 20);
            this.dtpTime.TabIndex = 3;
            // 
            // tmrCountHerDown
            // 
            this.tmrCountHerDown.Tick += new System.EventHandler(this.tmrCountHerDown_Tick);
            // 
            // btnCountDown
            // 
            this.btnCountDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCountDown.Font = new System.Drawing.Font("Alien Encounters Solid", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCountDown.Location = new System.Drawing.Point(400, 6);
            this.btnCountDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCountDown.Name = "btnCountDown";
            this.btnCountDown.Size = new System.Drawing.Size(107, 23);
            this.btnCountDown.TabIndex = 5;
            this.btnCountDown.Text = "START";
            this.btnCountDown.UseVisualStyleBackColor = false;
            this.btnCountDown.Click += new System.EventHandler(this.btnCountDown_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(33, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 9);
            this.label4.TabIndex = 6;
            this.label4.Text = "Enter Number of Hopurs to count down";
            // 
            // txtHoursToCountDown
            // 
            this.txtHoursToCountDown.Font = new System.Drawing.Font("Alien Encounters Solid", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoursToCountDown.Location = new System.Drawing.Point(290, 6);
            this.txtHoursToCountDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtHoursToCountDown.MaxLength = 400;
            this.txtHoursToCountDown.Name = "txtHoursToCountDown";
            this.txtHoursToCountDown.Size = new System.Drawing.Size(70, 25);
            this.txtHoursToCountDown.TabIndex = 7;
            this.txtHoursToCountDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblTargetDate
            // 
            this.lblTargetDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblTargetDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTargetDate.Font = new System.Drawing.Font("Alien Encounters Solid", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTargetDate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblTargetDate.Location = new System.Drawing.Point(733, 61);
            this.lblTargetDate.Name = "lblTargetDate";
            this.lblTargetDate.Size = new System.Drawing.Size(526, 51);
            this.lblTargetDate.TabIndex = 8;
            this.lblTargetDate.Text = "Target Date";
            this.lblTargetDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmMainCountDownTimer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 9F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1271, 145);
            this.Controls.Add(this.lblTargetDate);
            this.Controls.Add(this.txtHoursToCountDown);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnCountDown);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpTime);
            this.Controls.Add(this.lblCountDownDisplay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpTargetDate);
            this.Font = new System.Drawing.Font("Alien Encounters Solid", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmMainCountDownTimer";
            this.Text = "Count Down Timer";
            this.Load += new System.EventHandler(this.frmMainCountDownTimer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpTargetDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCountDownDisplay;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.Timer tmrCountHerDown;
        private System.Windows.Forms.Button btnCountDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtHoursToCountDown;
        private System.Windows.Forms.Label lblTargetDate;
    }
}

