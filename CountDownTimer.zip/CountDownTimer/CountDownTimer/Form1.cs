﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CountDownTimer
{
    public partial class frmMainCountDownTimer : Form
    {
        TimeSpan tsTimeToCountDown = new TimeSpan();
        DateTime dtTargetTime = new DateTime();
        string format = @"dd\ \ hh\:mm\:ss";
 

        public frmMainCountDownTimer()
        {
            InitializeComponent();
        }

        private void frmMainCountDownTimer_Load(object sender, EventArgs e)
        {
            dtpTargetDate.MinDate = DateTime.Now;
            tmrCountHerDown.Interval = 1000;

        }

        private void btnCountDown_Click(object sender, EventArgs e)
        {
            if (btnCountDown.Text == "START")
            {
                tmrCountHerDown.Enabled = true;
                btnCountDown.Text = "STOP";
                btnCountDown.BackColor = Color.Red;
                dtTargetTime = DateTime.Now.AddHours(double.Parse(txtHoursToCountDown.Text));
                lblTargetDate.Text = dtTargetTime.ToString("MM/dd/yyyy HH:mm:ss");
                //MessageBox.Show(dtTargetTime.ToString("MM/dd/yyyy HH:mm:ss"));
            }
            else
            {
                tmrCountHerDown.Enabled = false;
                btnCountDown.Text = "START";
                btnCountDown.BackColor = Color.LimeGreen;

            }
        }

        private void tmrCountHerDown_Tick(object sender, EventArgs e)
        {

            //99D  HH:MM:SS

            tsTimeToCountDown = dtTargetTime - DateTime.Now;

            lblCountDownDisplay.Text = tsTimeToCountDown.ToString(format);



        }
    }
}
